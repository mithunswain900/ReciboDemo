package com.recibodemo.DataBase;

import static com.recibodemo.DataBase.DbHelper.TABLE_RECIBO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.recibodemo.viewModel.DataViewModel;

import java.util.ArrayList;

public
class DataHelpManager {

    SQLiteDatabase db;
    Context context;

    public DataHelpManager(Context con) {
        this.context = con;
        SQLiteOpenHelper myHelper = new DbHelper(this.context);
        this.db = myHelper.getWritableDatabase();
        this.db = myHelper.getReadableDatabase();
    }

    public void insertItemToCart(String id, String first_name, String last_name, String phone_number) {
        ContentValues conV = new ContentValues();
        conV.put("id", id);
        conV.put("first_name", first_name);
        conV.put("last_name", last_name);
        conV.put("phone_number", phone_number);


        long newrow = db.insert(TABLE_RECIBO, null, conV);

        if (newrow >= 0) {
            //Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        } else {
            //Toast.makeText(context, "Failure", Toast.LENGTH_SHORT).show();
        }
    }


    public void insertItem(DataViewModel dataViewModel) {
        ContentValues conV = new ContentValues();
        conV.put("id",dataViewModel.getId());
        conV.put("first_name",dataViewModel.getFirstname());
        conV.put("last_name",dataViewModel.getLastname());
        conV.put("phone_number",dataViewModel.getPhonenumber());
    }

    @SuppressLint("Range")
    public ArrayList contentValuesArrayList(){

        ArrayList<String> array_list = new ArrayList<>();
        Cursor res =  db.rawQuery( " select * from DATABASE_NAME ", null );
        res.moveToFirst();

        while(res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex("5")));
            res.moveToNext();
        }
        return array_list;
    }
    }

