package com.recibodemo.viewModel;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.recibodemo.BR;
import com.recibodemo.Model.DataModel;

public
class DataViewModel extends BaseObservable  {

    private String id;
    public String firstname;
    public String lastname;
    public String phonenumber;

    public DataViewModel(String id,String firstname, String lastname, String phonenumber) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.phonenumber = phonenumber;
    }

    @Bindable
    public String getId(){
        return id;
    }
    public void setId(String id){
        this.id = id;
        notifyPropertyChanged(BR.id);

    }

    @Bindable
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
        notifyPropertyChanged(BR.firstname);

    }
    @Bindable
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
        notifyPropertyChanged(BR.lastname);

    }

    @Bindable
    public String getPhonenumber() {
        return phonenumber;
    }
    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
        notifyPropertyChanged(BR.phonenumber);

    }

   public void onCilcick(){

    }
}
