package com.recibodemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.database.DatabaseUtils;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.recibodemo.Adpter.DataViewAdpter;
import com.recibodemo.DataBase.DataHelpManager;
import com.recibodemo.Model.DataModel;
import com.recibodemo.databinding.ActivityMainBinding;
import com.recibodemo.databinding.LayoutTextviewBinding;
import com.recibodemo.utills.RecieboSharedPref;
import com.recibodemo.viewModel.DataViewModel;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding activityMainBinding;

    DataViewModel dataViewModel;
    public DataHelpManager dataHelpManager;
    RecieboSharedPref recieboSharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);
        activityMainBinding = DataBindingUtil.setContentView(MainActivity.this,R.layout.activity_main);
        dataHelpManager = new DataHelpManager(MainActivity.this);
        recieboSharedPref = new RecieboSharedPref(MainActivity.this);



        activityMainBinding.submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DataViewModel dataViewModel = new DataViewModel("1",activityMainBinding.edittextFirstname.getText().toString(),activityMainBinding.edittextLastname.getText().toString(),activityMainBinding.edittextPhoneNumber.getText().toString());
                dataHelpManager.insertItem(dataViewModel);
                Toast.makeText(MainActivity.this, "DataSaved Successfully", Toast.LENGTH_SHORT).show();
                recieboSharedPref.setPreferenceData("first_name",activityMainBinding.edittextFirstname.getText().toString());
                recieboSharedPref.setPreferenceData("last_name",activityMainBinding.edittextLastname.getText().toString());
                recieboSharedPref.setPreferenceData("phone_number",activityMainBinding.edittextPhoneNumber.getText().toString());

            }
        });

/*
        activityMainBinding.viewDataBaseModel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                LayoutTextviewBinding layoutTextviewBinding = DataBindingUtil.inflate(LayoutInflater.from(MainActivity.this),
                        R.layout. layout_textview, null, false);
                final View customLayout = layoutTextviewBinding.getRoot();
               builder.setView(customLayout);
                final AlertDialog dialog = builder.create();
                layoutTextviewBinding.dataRecycler.setHasFixedSize(true);
                RecyclerView.LayoutManager manager = new LinearLayoutManager(MainActivity.this);
                layoutTextviewBinding.dataRecycler.setLayoutManager(manager);
                DataViewAdpter dataViewAdpter = new DataViewAdpter(MainActivity.this, dataHelpManager.contentValuesArrayList());
                layoutTextviewBinding.dataRecycler.setAdapter(dataViewAdpter);
                dialog.show();
            }
        });
*/

    }

    @Override
    protected void onResume() {
        super.onResume();

        activityMainBinding.edittextPhoneNumber.setText(recieboSharedPref.getPreferenceData("phone_number"));
        activityMainBinding.edittextFirstname.setText(recieboSharedPref.getPreferenceData("first_name"));
        activityMainBinding.edittextLastname.setText(recieboSharedPref.getPreferenceData("last_name"));


    }
}