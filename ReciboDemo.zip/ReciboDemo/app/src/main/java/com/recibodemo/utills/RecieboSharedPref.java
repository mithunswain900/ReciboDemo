package com.recibodemo.utills;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.ArrayList;

public class RecieboSharedPref {

    private SharedPreferences pref;
    private Context context;
    private SharedPreferences.Editor editor;

    public RecieboSharedPref(Context ctx){
        this.context = ctx;
        pref = PreferenceManager.getDefaultSharedPreferences(this.context);
        editor = pref.edit();
    }

    public void setPreferenceData(String key, String value){
        editor.putString(key, value);
        editor.commit();
    }
    public String getPreferenceData(String key){
        String id = pref.getString(key, "");
        return id;
    }

    /*Clear the Preference*/
    public void clearPreference(){
        editor.clear();
        editor.apply();

    }
    public void removPreference(String key){
        editor.remove(key);
    }


    //arry
    public  void setArrayPrefs(String key, ArrayList<String> array) {


        editor.putInt(key +"_size", array.size());
        for(int i=0;i<array.size();i++)
            editor.putString(key + "_" + i, array.get(i));
        editor.apply();
    }

    public ArrayList<String> getArrayPrefs(String key) {
        int size = pref.getInt(key + "_size", 0);
        ArrayList<String> array = new ArrayList<>(size);
        for(int i=0;i<size;i++)
            array.add(pref.getString(key + "_" + i, null));
        return array;
    }


}
