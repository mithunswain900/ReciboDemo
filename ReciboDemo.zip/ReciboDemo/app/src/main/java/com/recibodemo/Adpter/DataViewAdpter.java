package com.recibodemo.Adpter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.recibodemo.R;
import com.recibodemo.databinding.LayoutDataItemsBinding;
import com.recibodemo.viewModel.DataViewModel;

import java.util.ArrayList;

public
class DataViewAdpter extends RecyclerView.Adapter<DataViewAdpter.ViewHolder> {

    private Context context;
    ArrayList<DataViewModel> dataViewModelArrayList;

    LayoutInflater layoutInflater;

    public DataViewAdpter(Context context, ArrayList<DataViewModel> dataViewModelArrayList) {
        this.context = context;
        this.dataViewModelArrayList = dataViewModelArrayList;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutDataItemsBinding layoutDataItemsBinding =
                DataBindingUtil.inflate(layoutInflater, R.layout.layout_data_items, parent, false);
        return new ViewHolder(layoutDataItemsBinding);    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.layoutDataItemsBinding.itemsData.setText(dataViewModelArrayList.get(position).getFirstname());
        holder.layoutDataItemsBinding.itemsDataTwo.setText(dataViewModelArrayList.get(position).getLastname());
        holder.layoutDataItemsBinding.itemsDataThree.setText(dataViewModelArrayList.get(position).getPhonenumber());

    }

    @Override
    public int getItemCount() {
        return dataViewModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        LayoutDataItemsBinding layoutDataItemsBinding;

        public ViewHolder(LayoutDataItemsBinding layoutDataItemsBinding) {
            super(layoutDataItemsBinding.getRoot());
            this.layoutDataItemsBinding = layoutDataItemsBinding;
        }
    }
}
